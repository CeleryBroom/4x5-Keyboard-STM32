#include "main.h"
#include "usbd_hid.h"
#include "usb_device.h"

extern USBD_HandleTypeDef hUsbDeviceFS;
    
void KeyBoardPrint(char *data, uint16_t length);

void light_switch(void);

void scan_matrix(void);
void scan_matrix1(void);